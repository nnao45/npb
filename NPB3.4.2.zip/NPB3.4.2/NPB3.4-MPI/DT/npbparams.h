#define CLASS 'S'
/*
   This file is generated automatically by the setparams utility.
   It sets the number of processors and the class of the NPB
   in this directory. Do not modify it by hand.   */
   
#define NUM_SAMPLES 1728
#define STD_DEVIATION 128
#define NUM_SOURCES 4
#define COMPILETIME "25 Jul 2021"
#define NPBVERSION "3.4.2"
#define MPICC "mpicc"
#define CFLAGS "-O3"
#define CLINK "$(MPICC)"
#define CLINKFLAGS "$(CFLAGS)"
#define CMPI_LIB "(none)"
#define CMPI_INC "(none)"
